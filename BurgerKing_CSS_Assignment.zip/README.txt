CPIS358 Burger King website with external, internal, inline CSS, general classes, z-index layering, shadows, borders, menu and consistent page layout.
Open index.html. Add the original images to images/. PHP form handlers and JavaScript functionality are NOT supplied; forms will not process until server endpoints are implemented.
